#include<iostream>
#include<string>
#include<stdlib.h>

#include "simplex.h" 

using namespace std;


double topnesscompute(double pb1[4], double pb2[4], double pl[4], double MET[4], double sigmat, double sigmaW, double sigmas, double xbest[4]);
