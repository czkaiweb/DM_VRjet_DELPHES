from info import Info
from advprint import AdvPrint
from checkmate_core import CheckMATE2

x = CheckMATE2()

